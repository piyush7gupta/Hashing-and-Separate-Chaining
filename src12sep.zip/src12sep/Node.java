/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author piyus
 */
public class Node<K,T> {
    
    K key;
    T obj;
     Node<K,T> left ;
     Node<K,T> right;
     
    
}
